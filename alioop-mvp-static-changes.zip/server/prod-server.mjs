import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const port = process.env.PORT ? Number(process.env.PORT) : 4000

// Serve static files from /dist if it exists
const distPath = path.join(__dirname, '..', 'dist')
app.use(express.static(distPath))

// Simple API (duplicate of dev API)
app.get('/api/test', (req, res) => {
  res.json({ message: 'Mock API is working (prod)!' })
})

// Fallback to index.html for SPA routes when dist is available
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next()
  res.sendFile(path.join(distPath, 'index.html'), err => {
    if (err) next()
  })
})

app.listen(port, () => {
  console.log(`Production server running on http://localhost:${port}`)
})
