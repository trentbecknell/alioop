import express from "express";
const app = express();
const port = 4000;

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "http://localhost:5173");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.get("/api/test", (req, res) => {
  res.json({ message: "Mock API is working!" });
});

app.listen(port, () => {
  console.log(`Mock API server running on http://localhost:${port}`);
});
