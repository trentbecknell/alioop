// placeholder for potential seeded data
module.exports = {
  DEFAULT_FOLDERS: ["01_Assets", "02_Mixes", "03_Masters", "04_Deliverables", "05_Invoices"],
}
